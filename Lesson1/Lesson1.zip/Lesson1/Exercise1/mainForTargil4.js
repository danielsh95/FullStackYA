let targil4 = require('./targil4')

targil4.funcB_Async().then(x => console.log(x * 2));
