let utilsFile = require('./utils')

let result = utilsFile.getUserDataByUserId(2)
console.log(result)