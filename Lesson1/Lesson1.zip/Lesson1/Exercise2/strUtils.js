function getLength(str)
{
    return str.length;
}

module.exports = {getLength}