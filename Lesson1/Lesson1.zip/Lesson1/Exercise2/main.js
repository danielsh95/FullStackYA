let arrUtils = require('./arrUtils')

let arr = [ "Daniel", "Yosi", "goldi", "netanyau" ]

total = arrUtils.getArrLength(arr);
console.log("total is: " + total);